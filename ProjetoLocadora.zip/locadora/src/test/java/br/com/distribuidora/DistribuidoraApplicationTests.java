package br.com.distribuidora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistribuidoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
